<?php
    /**
     * Plugin Name: Infusionsoft Token Manager
     * Description: This is a basic plugin that manages infusionsoft tokens.
     * Version: 0.1.0
     * Author: Marcos Centeno
     */
    if ( !defined( 'ABSPATH' ) ) wp_die();
?>